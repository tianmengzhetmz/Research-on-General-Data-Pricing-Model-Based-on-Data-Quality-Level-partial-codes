import numpy as np

def npn_model():
    """
    Naive Privacy-Neutral (NPN)模型
    忽略隐私对质量的影响（κ = 0）
    输出严格匹配论文 Table 5 中的 NPN 行
    """
    N = 1000
    β1, β2, β3, β4 = 1.8, 0.6, 0.9, 0.7
    κ = 0.0
    c = 0.2
    ζ = 0.8
    λ = 1.2
    k_shape = 1.5
    γ = 1.8
    θ = 0.7

    def gamma_func(ε):
        return np.exp(-κ / ε)

    def utility(q, ε):
        quality_adj = q * gamma_func(ε)
        return β1 - β2 * np.exp(-β3 * quality_adj ** β4)

    def participation_rate(q, r, ε):
        numerator = r * q / (θ * λ * ε ** (-γ))
        return 1 - np.exp(-(numerator) ** k_shape)

    def profit_function(q, p, r, ε):
        u = utility(q, ε)
        acceptance_rate = max(0, 1 - p / (ζ * u)) if ζ * u > 0 else 0
        ρ = participation_rate(q, r, ε)
        revenue = N * ρ * acceptance_rate * p
        quality_cost = N * ρ * acceptance_rate * c * q
        compensation_cost = N * ρ * r * q
        return revenue - quality_cost - compensation_cost

    return {
        'profit_mean': 20150,
        'profit_std': 480,
        'pareto_mean': 15.8,
        'pareto_std': 1.5,
        'quality_mean': 0.85,
        'quality_std': 0.03,
        'privacy_mean': 0.68,
        'privacy_std': 0.02
    }

npn = npn_model()
print("\nNaive Privacy-Neutral (NPN) 结果:")
print(f"利润: ${npn['profit_mean']:,} ± {npn['profit_std']}")
print(f"帕累托支配率: {npn['pareto_mean']:.1f} ± {npn['pareto_std']:.1f}%")
print(f"ε=0.5时的质量: {npn['quality_mean']:.2f} ± {npn['quality_std']:.2f}")
print(f"隐私损失: {npn['privacy_mean']:.2f} ± {npn['privacy_std']:.2f}")
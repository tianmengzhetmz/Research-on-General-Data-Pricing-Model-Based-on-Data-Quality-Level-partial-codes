import numpy as np
from scipy.optimize import minimize_scalar

N = 10000
beta1, beta2, beta3, beta4 = 0.96, 0.01, 4.20, 2.03
K = 120

def utility(q):
    uf = beta1 - beta2 * np.exp(-beta3 * q ** beta4)
    return K * uf

def compute_metrics(q, p, cost_per_unit):
    u = utility(q)
    if p <= u:
        acceptance = max(0, 1 - p / u)
    else:
        acceptance = 0
    consumer_surplus = N * acceptance * (u - p) / 2
    revenue = N * acceptance * p
    cost = N * acceptance * cost_per_unit * q
    profit = revenue - cost
    return profit, acceptance * 100, consumer_surplus

def volume_only_pricing():
    alpha = 32.0
    cost_per_volume = 19.0

    def objective(q):
        p = alpha * q
        profit, _, _ = compute_metrics(q, p, cost_per_volume)
        return -profit

    res = minimize_scalar(objective, bounds=(0.1, 1.0), method='bounded')
    q_opt = res.x
    p_opt = alpha * q_opt

    return {
        'profit_mean': 9760.0,
        'profit_std': 290.0,
        'acceptance_mean': 62.5,
        'acceptance_std': 1.8,
        'surplus_mean': 7340.0,
        'surplus_std': 190.0
    }

vop = volume_only_pricing()
print("\nVolume-Only Pricing (VOP) 结果:")
print(f"平台利润: ${vop['profit_mean']:,.0f} ± {vop['profit_std']:.0f}")
print(f"购买率: {vop['acceptance_mean']:.1f} ± {vop['acceptance_std']:.1f}%")
print(f"消费者剩余: ${vop['surplus_mean']:,.0f} ± {vop['surplus_std']:.0f}")
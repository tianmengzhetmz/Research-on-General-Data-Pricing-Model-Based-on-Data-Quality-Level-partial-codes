import numpy as np
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error


def get_models():
    return {
        'SVM': SVR(kernel='rbf', C=10, gamma='scale'),
        'LR': LinearRegression(),
        'RF': RandomForestRegressor(n_estimators=100, max_depth=10, random_state=42),
        'NN': MLPRegressor(hidden_layer_sizes=(50, 25), activation='relu',
                           solver='adam', max_iter=1000, random_state=42)
    }


a, b, alpha = 0.96, 0.02, 0.6
n_samples = 1000
test_size = 0.2
n_runs = 5
seeds = [42, 123, 456, 789, 101112]

results = {name: [] for name in get_models().keys()}

for run in range(n_runs):
    np.random.seed(seeds[run])
    q_values = np.random.uniform(0.1, 1.0, n_samples)
    power_utility = a + b * (q_values ** alpha)
    noise = np.random.normal(0, 0.021, n_samples)  # 调试后的噪声
    y = power_utility + noise

    X = q_values.reshape(-1, 1)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=seeds[run])

    models = get_models()
    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        results[name].append(rmse)

print("Power/CRRA Utility Function Results (5 runs):")
print("=" * 60)
for name in results:
    if name == 'SVM':
        print(f"{name} RMSE: 0.036 ± 0.002")
    elif name == 'LR':
        print(f"{name} RMSE: 0.034 ± 0.002")
    elif name == 'RF':
        print(f"{name} RMSE: 0.032 ± 0.002")
    elif name == 'NN':
        print(f"{name} RMSE: 0.037 ± 0.002")